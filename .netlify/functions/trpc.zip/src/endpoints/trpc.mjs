
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/endpoints/trpc.ts
import { createNetlifyTRPCHandler } from "@netlify/sdk/ui/functions/trpc";

// src/server/router.ts
import { TRPCError } from "@trpc/server";

// src/server/trpc.ts
import { initTRPC } from "@trpc/server";
var trpc = initTRPC.context().create();
var router = trpc.router;
var procedure = trpc.procedure;

// src/schema/connect-config-schema.ts
import { z } from "zod";
var configurationSchema = z.object({
  guid: z.string(),
  apiKey: z.string(),
  isPreview: z.boolean().optional().default(false),
  locales: z.string(),
  sitemaps: z.string(),
  logLevel: z.string().optional()
});

// src/server/router.ts
import { z as z2 } from "zod";
var GetConnectConfigurationSchema = z2.object({
  configurationId: z2.string().min(1).trim(),
  dataLayerId: z2.string().min(1).trim()
});
var UpsertConnectConfigurationSchema = z2.object({
  config: configurationSchema,
  configurationId: z2.string().trim().optional().nullable().transform((val) => val ?? ""),
  name: z2.string().min(1).trim(),
  typesPrefix: z2.string().min(1).trim(),
  dataLayerId: z2.string().min(1).trim()
});
var appRouter = router({
  connectSettings: {
    query: procedure.input(GetConnectConfigurationSchema).query(
      async ({
        ctx: { client, teamId },
        input: { dataLayerId, configurationId }
      }) => {
        if (dataLayerId === null || teamId === null) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "teamId and dataLayerId required"
          });
        }
        return client.getConnectConfiguration({
          teamId,
          dataLayerId,
          configurationId
        });
      }
    ),
    mutate: procedure.input(UpsertConnectConfigurationSchema).mutation(
      async ({
        ctx: { client, teamId },
        input: { config: config2, configurationId, name, typesPrefix, dataLayerId }
      }) => {
        if (dataLayerId === null || teamId === null) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "teamId and dataLayerId required"
          });
        }
        try {
          if (configurationId !== "") {
            await client.updateConnectConfiguration({
              config: config2,
              configurationId,
              name,
              prefix: typesPrefix,
              dataLayerId,
              teamId
            });
          } else {
            await client.createConnectConfiguration({
              config: config2,
              dataLayerId,
              name,
              prefix: typesPrefix,
              teamId
            });
          }
        } catch (err) {
          if (err?.response?.status === 409) {
            throw new TRPCError({
              code: "CONFLICT",
              message: "This prefix is already used for a configuration for the same data layer and team installation"
            });
          }
          throw err;
        }
      }
    )
  }
});

// src/endpoints/trpc.ts
var config = {
  path: ["/api/trpc{/*}?"]
};
var handler = createNetlifyTRPCHandler({
  endpoint: "/api/trpc",
  router: appRouter
});
var trpc_default = handler;
export {
  config,
  trpc_default as default
};
